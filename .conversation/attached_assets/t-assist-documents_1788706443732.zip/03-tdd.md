# T-Assist — Technical Design Document (TDD)

**Builds on:** 01-foundation.md, 02-prd.md — architecture decisions here exist to serve the MVP scope already locked in those documents.

---

## Stack overview

| Layer | Choice | Notes |
|---|---|---|
| Backend | Flask | Consistent with Leo's other apps (T-Notes, result app) |
| Database | PostgreSQL | |
| AI provider | Google Gemini (AI Studio free tier) | Handles text, image, and audio input natively — no separate STT service needed for voice notes at this stage |
| Frontend | Not yet decided | Out of scope for this document; to be addressed when frontend build starts |
| Auth | Lightweight session-based, name + age/class + PIN | See Auth section below |
| Hosting | Not yet decided | To be researched when ready to deploy (free-tier hosting research, similar to AJOKE HUB's approach, recommended at that point) |

## Why Gemini specifically

- Free tier supports multimodal input (text, image, audio) in a single API — this directly simplifies the voice-note and image pipelines from the PRD, since a photo of a textbook problem or a voice note can go straight to Gemini rather than needing a separate vision model and a separate Whisper-style STT step
- Trade-off to track: free-tier rate limits are real (request-per-day ceilings that vary by model) and can tighten without warning — this is fine for MVP/testing, but will need revisiting before real usage scales
- Privacy note to carry into the rules document and eventually a user-facing privacy notice: outside the EEA/UK/Switzerland, free-tier prompts may be used by Google to improve their products. Worth deciding explicitly how this gets disclosed to students/parents, since this is a children's product

## Auth design

- Signup collects: name, age/class level, a self-chosen PIN (4–6 digits) — no email/password required
- Rationale: matches the PRD's "signup required" decision while keeping friction low for a young audience
- Session: long-lived session token/cookie after signup so students aren't re-entering a PIN constantly
- No password-reset flow needed at this stage (no email on file) — if a PIN is forgotten, re-signup or a simple recovery mechanism can be designed later; not a blocker for MVP

## Data model (initial draft — to be tested against a real database before trusted, per the workflow brief)

**students**
- id (PK)
- name
- age_or_class_level
- pin_hash
- created_at
- last_active_at
- current_streak_count
- longest_streak_count

**conversations**
- id (PK)
- student_id (FK → students)
- started_at
- channel (enum: web, whatsapp — whatsapp unused until Phase B)

**messages**
- id (PK)
- conversation_id (FK → conversations)
- sender (enum: student, temmy)
- content_type (enum: text, voice, image)
- content_text (the text itself, or transcribed/derived text for voice/image)
- raw_media_url (nullable — original voice/image file, if stored)
- created_at

**progress_topics**
- id (PK)
- student_id (FK → students)
- subject
- topic
- first_covered_at
- last_covered_at
- times_discussed

**badges**
- id (PK)
- student_id (FK → students)
- badge_type
- awarded_at

*(Badge trigger definitions are flagged as an open item from the PRD — to be defined before this table's logic is built, not before the table itself exists.)*

## API routes (initial draft)

**Auth**
- `POST /api/signup` — name, age/class, PIN → creates student, returns session
- `POST /api/login` — name/id + PIN → returns session

**Chat**
- `POST /api/chat/message` — send text/voice/image, get Temmy's response
- `GET /api/chat/history` — retrieve a student's conversation history

**Progress**
- `GET /api/progress` — topics covered, streak, badges for the logged-in student

## Companion service (core logic layer)

Sits between the API routes and Gemini. Responsibilities:
1. Pull student context (age/class, recent topics, streak status) before building the prompt
2. Route the incoming message by content type: text passes through directly; voice/image get sent to Gemini's multimodal input alongside the context
3. Apply Temmy's persona/tone rules (full detail belongs in the rules document, next)
4. Log the interaction to `messages` and update `progress_topics`
5. Check streak/badge logic after each interaction

## Security considerations

- PINs stored hashed, never in plaintext
- Session tokens should expire and be renewable, not infinite
- Rate-limit the chat endpoint per student to control Gemini API usage against free-tier limits
- Validate/sanitize any uploaded images before sending to Gemini

## Build sequence (front-loading the highest-risk piece, per the workflow brief's discipline)

1. Student model + auth (signup/login) — foundation everything else depends on
2. Companion service with Gemini text-only — validate Temmy's tone/quality before adding complexity
3. Voice + image input handling through Gemini's multimodal support
4. Progress tracking (`progress_topics`)
5. Gamification (streaks, badges)
6. Frontend build/integration (or reconciliation, if frontend is built separately — see workflow brief Phase 5 discipline)

---

*Next document: Rules document (coding/dev discipline for whichever AI tool builds this — PROJECT_BRIEF-style continuity)*

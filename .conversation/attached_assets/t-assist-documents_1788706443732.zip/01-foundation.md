# T-Assist — Foundation Document

**Purpose:** lock down the core product decisions before any PRD, architecture, or code. Everything downstream (PRD, TDD, schema, build) treats this document as the source of truth for scope and intent.

---

## Naming

- **Web app:** T-Assist
- **Chatbot / companion persona:** Temmy (this is who the student actually talks to and forms a relationship with, on both web and WhatsApp)

## What this is

An AI study companion for primary and secondary school students — accessible as a web app (T-Assist) and on WhatsApp — that helps students learn faster by acting like a friend, not a generic Q&A tool. The personality and relationship is the differentiator, not just the teaching content. Temmy is the persona/brain behind both channels.

## Who it's for

- Primary and secondary school students, both served from launch
- Tone and difficulty adapt by age/class level — same product, not two separate experiences
- Student owns the relationship directly (full autonomy, not parent/teacher-mediated)
- Open to any student, anywhere — no school gatekeeping, no license requirement

## Subject scope

Not curriculum-bound. Any subject a student brings, from day one. No restriction to a fixed set of "core" subjects.

## Access & monetization

- Free for individual students
- No payment system for now — deliberately deferred, can be added later once the core experience is proven
- No school/institutional layer for now — deliberately deferred

## Platforms

- Web app and WhatsApp, both backed by one shared brain and one student profile/memory store
- Student identity persists across both channels

## Input types (from launch)

- Text
- Voice notes (requires speech-to-text before reaching the AI)
- Images (e.g. a photo of a textbook problem or handwritten work, requires a vision-capable step)

## Non-negotiable behavior rule

When a student asks the companion to just solve their homework for them: **it's a mix, not a fixed rule.** Some questions warrant a direct answer, others warrant Socratic guidance toward the answer. The companion needs judgment here, not a blanket policy — this will need more specific guidance in the rules document once the AI's decision logic is designed.

## Explicitly out of scope for now

- Payments/monetization of any kind
- School dashboards, licenses, or admin views
- Curriculum-specific content (e.g. Nigerian NERDC alignment) — general study help only

## Tech stack decision

- Backend: Flask, consistent with Leo's other apps (T-Notes, result app)
- WhatsApp integration: starting from zero — no prior WhatsApp Business API experience

## Timeline

Not yet estimated — to be addressed in the PRD once MVP scope is defined.

---

*Next document: PRD (MVP scope vs. non-goals, user flows, feature list)*

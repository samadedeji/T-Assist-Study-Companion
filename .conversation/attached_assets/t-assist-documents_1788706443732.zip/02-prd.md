# T-Assist — Product Requirements Document (PRD)

**Builds on:** 01-foundation.md — treat that document as settled context; this PRD defines what actually ships in the MVP.

---

## Product summary

T-Assist is a web app where students chat with Temmy, an AI study companion that helps them learn faster by relating to them like a friend rather than answering like a generic bot. WhatsApp is a planned second channel, built after the web version is working well.

## Launch sequencing

1. **Phase A (this PRD's focus):** T-Assist web app, fully functional
2. **Phase B (later):** WhatsApp integration, reusing the same backend/companion brain and student profile

## MVP scope

### 1. Signup & student profile
- Signup required before first chat: name, age/class level
- Age/class level drives tone and difficulty adaptation in Temmy's responses
- Profile persists across sessions (this is the foundation of "Temmy remembers you")

### 2. Core chat with Temmy
- Text-based chat as the baseline interaction
- Voice notes: speech-to-text conversion before reaching Temmy
- Images: student can send a photo (e.g. textbook problem, handwritten work) for Temmy to read and respond to
- Temmy's responses adapt tone/vocabulary to the student's age/class level
- Any subject, no curriculum restriction
- Direct answer vs. guided/Socratic response is a judgment call per question, not a fixed rule (see rules document, to follow)

### 3. Progress tracking
- Basic record of what's been covered per student (subjects/topics discussed)
- Visible to the student as a simple view of their own learning activity
- No school/parent visibility in this phase (per Foundation: no school layer for now)

### 4. Gamification
- Streaks: track consecutive days of engagement
- Badges: awarded for milestones (exact trigger list to be defined during design, not blocking MVP scope definition)

## Non-goals for this phase

- WhatsApp integration (explicitly Phase B, not bundled into this MVP)
- Payments or any monetization
- School dashboards, licenses, or admin/parent views
- Curriculum-specific content alignment (e.g. Nigerian NERDC scheme of work)
- Advanced adaptive learning paths or formal lesson plans — Temmy responds to what the student brings, it doesn't run a curriculum

## User flow (happy path)

1. Student lands on T-Assist, signs up (name, age/class)
2. Student starts chatting with Temmy — text, voice, or image
3. Temmy responds in a tone suited to the student's age, either answering directly or guiding them, depending on the question
4. Interaction is logged to the student's progress record
5. Streak updates if this is a new day of engagement; badges awarded if a milestone is hit
6. Student can view their own progress (topics covered, streak, badges) somewhere in the app

## Drop-off points to design around

- Student abandons signup before completing it (name/age fields)
- Student sends an image/voice note that fails to process (STT or vision step fails) — needs a graceful fallback, not a dead end
- Student goes quiet for a while — streak breaks; worth considering (not required for MVP) whether Temmy re-engages, but this is a Phase B+ consideration

## Open items for the TDD

- Speech-to-text and vision model choices
- Memory storage design (what "remembers you" actually persists and how much)
- Badge trigger definitions
- Session/auth mechanism for the web app

---

*Next document: TDD (architecture, stack, data model, API design)*

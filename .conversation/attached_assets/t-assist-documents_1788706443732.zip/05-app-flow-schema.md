# T-Assist — App Flow & Schema

**Builds on:** 01-foundation.md, 02-prd.md, 03-tdd.md, 04-rules.md.

**Schema status: tested against a real PostgreSQL 16 database.** Every table was created, every happy-path insert succeeded, and every failure case below was deliberately triggered and confirmed to error correctly. Nothing in this document is trusted on read alone, per the rules document's discipline.

---

## Customer journey (step by step)

1. **Landing** — student arrives at T-Assist for the first time
2. **Signup** — name, age/class level, self-chosen PIN
   - *Drop-off risk: student abandons before completing all three fields.* Keep this form as short as it already is; don't add fields later without weighing this risk.
3. **First chat with Temmy** — student sends a text, voice note, or image
   - *Drop-off risk: voice/image fails to process (Gemini timeout, unsupported format).* Needs a graceful, friendly fallback message from Temmy, not a dead end or raw error.
4. **Temmy responds** — tone adapted to age/class, either direct answer or guided response depending on the question
5. **Interaction logged** — message pair saved, `progress_topics` updated (new row if first time on that subject/topic, `times_discussed` incremented if not)
6. **Streak check** — if this is the student's first interaction today, `current_streak_count` increments (or resets to 1 if the streak was broken); `longest_streak_count` updates if beaten
7. **Badge check** — server checks badge-eligibility rules against logged data (e.g. first chat, streak milestones); awards if met
8. **Student can view progress** — topics covered, current streak, badges earned
9. **Return visits** — student logs in with name/id + PIN, session resumes, Temmy has their history available as context

### Drop-off points to design around (carried from PRD, now mapped to schema)

| Drop-off | Where it happens | Mitigation |
|---|---|---|
| Abandons signup | Before a `students` row exists | Keep form minimal (already 3 fields) |
| Voice/image processing fails | Before a `messages` row is created for Temmy's reply | Friendly fallback response, log the failure separately from normal messages, don't silently lose the student's input |
| Streak breaks (goes quiet) | `current_streak_count` resets | Not required for MVP, but the schema supports a later "Temmy checks in" feature without changes, since `last_active_at` is already tracked |

## Schema (verified)

```sql
CREATE TABLE students (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL CHECK (btrim(name) <> ''),
    age_or_class_level VARCHAR(50) NOT NULL CHECK (btrim(age_or_class_level) <> ''),
    pin_hash VARCHAR(255) NOT NULL CHECK (btrim(pin_hash) <> ''),
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    last_active_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    current_streak_count INTEGER NOT NULL DEFAULT 0 CHECK (current_streak_count >= 0),
    longest_streak_count INTEGER NOT NULL DEFAULT 0 CHECK (longest_streak_count >= 0)
);

CREATE TABLE conversations (
    id SERIAL PRIMARY KEY,
    student_id INTEGER NOT NULL REFERENCES students(id) ON DELETE CASCADE,
    started_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    channel VARCHAR(20) NOT NULL CHECK (channel IN ('web', 'whatsapp'))
);

CREATE TABLE messages (
    id SERIAL PRIMARY KEY,
    conversation_id INTEGER NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
    sender VARCHAR(10) NOT NULL CHECK (sender IN ('student', 'temmy')),
    content_type VARCHAR(10) NOT NULL CHECK (content_type IN ('text', 'voice', 'image')),
    content_text TEXT NOT NULL CHECK (btrim(content_text) <> ''),
    raw_media_url TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE progress_topics (
    id SERIAL PRIMARY KEY,
    student_id INTEGER NOT NULL REFERENCES students(id) ON DELETE CASCADE,
    subject VARCHAR(100) NOT NULL CHECK (btrim(subject) <> ''),
    topic VARCHAR(200) NOT NULL CHECK (btrim(topic) <> ''),
    first_covered_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    last_covered_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    times_discussed INTEGER NOT NULL DEFAULT 1 CHECK (times_discussed > 0),
    UNIQUE (student_id, subject, topic)
);

CREATE TABLE badges (
    id SERIAL PRIMARY KEY,
    student_id INTEGER NOT NULL REFERENCES students(id) ON DELETE CASCADE,
    badge_type VARCHAR(50) NOT NULL CHECK (btrim(badge_type) <> ''),
    awarded_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_conversations_student ON conversations(student_id);
CREATE INDEX idx_messages_conversation ON messages(conversation_id);
CREATE INDEX idx_progress_student ON progress_topics(student_id);
CREATE INDEX idx_badges_student ON badges(student_id);
```

## Verification log

**Happy path (all succeeded):**
- Insert student → insert conversation → insert two messages (student + Temmy) → insert progress_topics row → insert badge

**Failure cases (all correctly rejected):**
- Empty string name → rejected by CHECK constraint
- Whitespace-only name (`'   '`) → rejected by CHECK constraint (this is the exact gap that `NOT NULL` alone misses, per the AJOKE HUB lesson in the rules document — pre-empted here with `btrim`)
- NULL name → rejected by NOT NULL constraint
- Invalid `channel` value (`'sms'`) → rejected by CHECK constraint
- Invalid `content_type` value (`'fax'`) → rejected by CHECK constraint
- Negative streak count → rejected by CHECK constraint
- Duplicate `(student_id, subject, topic)` → rejected by UNIQUE constraint
- Foreign key to a nonexistent student → rejected by FK constraint

## Open item carried forward

- Badge trigger definitions (which milestones award which `badge_type`) are still undefined — this schema supports them but doesn't decide them. Define these when building the companion service's badge-check logic, not before.

---

*Planning documents complete: Foundation → PRD → TDD → Rules → App Flow & Schema. Next: active build, starting with student model + auth per the TDD's build sequence.*

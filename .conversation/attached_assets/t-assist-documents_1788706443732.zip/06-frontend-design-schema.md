# T-Assist — Frontend Design Schema

**Builds on:** 01-foundation.md, 02-prd.md. This defines the visual identity and page/component structure before frontend code is built.

**Direction locked in:** playful and colorful, leaning primary-school energy even though secondary students use it too. Explicitly not a notebook/paper aesthetic.

---

## Design tokens

### Color

| Name | Hex | Role |
|---|---|---|
| Cloud | `#F7F5FF` | Page background — cool lavender-white, not cream |
| Ink | `#241E46` | Primary text — deep indigo-plum, not flat black |
| Temmy violet | `#7C5CFC` | Primary brand color — Temmy's chat bubble, primary buttons, nav |
| Ember | `#FF8A3D` | Streak/energy accent — flame icon, urgency-free highlights |
| Grove | `#2FD1A0` | Growth/success accent — badges, correct-answer moments, progress bar fill |
| Spark | `#FFD23F` | Celebration accent — badge medallions, confetti-style moments, used sparingly |
| Dusk | `#241D4A` | Dark surface — footer, nav-on-scroll, contrast panels |

Five colors used deliberately, not a rainbow: violet carries the brand, ember and grove carry two different kinds of feedback (energy vs. growth), spark is reserved for genuine celebration moments so it doesn't get diluted.

### Type

- **Display / headlines / Temmy's chat bubble text:** Baloo 2 — rounded terminals read as warm and approachable without being purely childish at heavier weights, which matters since both primary and secondary students see it
- **Body / UI / forms:** Manrope — clean, legible at small sizes, stays out of the way

Two families, clearly distinct roles: Baloo 2 speaks with personality, Manrope handles information.

### Layout principles

1. **Temmy's chat bubble is the one bold visual element.** Rounded, violet-filled, distinct shape from the student's own message bubble. Everything else (nav, forms, buttons) stays quiet so this doesn't get diluted.
2. **No notebook or paper textures anywhere** — replaced with soft, slow-drifting color blobs in the background (violet/ember/grove at low opacity) to carry warmth without looking like a worksheet.
3. **Feature sections use an asymmetric grid**, not identical repeated cards — content that isn't actually a numbered sequence doesn't get numbered markers.
4. **One orchestrated hero motion**: the landing page hero shows Temmy actually replying in a live-feeling chat preview, since a chat companion's hero is a conversation, not a screenshot. Motion elsewhere (sending a message, a badge appearing) responds to the student's own actions, not scroll-triggered animation on every section.
5. **Streak and badges stay visible near the chat input**, not buried behind a separate dashboard-only page — the gamification should feel like part of the conversation, not a chore to go check.

## Copy rules

- **No em dashes, anywhere** — not in UI copy, headlines, button labels, Temmy's own chat responses, or error messages. Use periods, commas, or restructure the sentence instead.
- No ALL CAPS labels or eyebrows above headings.
- No middle-dot-joined meta strings ("A · B · C") or arrow-suffixed button text ("Continue →").
- Write from the student's perspective, in plain language, not system language ("Send a photo" not "Upload media asset").

## Page structure

### Landing page
- Hero: live chat preview animation (Temmy responding to a sample question), headline, one CTA ("Start chatting" or similar action-first copy)
- Feature section (asymmetric grid): talk to Temmy in any subject, send a photo of your homework, voice notes, track your streak
- Simple footer

### Signup
- Single short form: name, age/class level, PIN — matches the low-friction decision from the TDD

### Chat (core experience)
- Persistent streak indicator near the input (not a separate page)
- Temmy's bubble (violet, rounded) vs. student's bubble (lighter, neutral)
- Input row supports text, voice note, and image attach
- Badge earned moment appears inline in the conversation when triggered, not just on a dashboard

### Progress view
- Topics covered, current streak, badges earned — simple, not data-dense

---

*Next: build the actual mockup to see this in motion before writing production frontend code.*

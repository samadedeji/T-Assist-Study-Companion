# T-Assist — Rules Document (Dev Discipline for AI Tools)

**Purpose:** this document is for whichever AI tool is actively building T-Assist (this chat, Claude Code, Copilot, or any future tool/session). It carries forward the discipline that made AJOKE HUB work, adapted to this project's architecture. Read this before writing code.

**Authority:** where this document and your own inference disagree, this document is correct. If a claim here was verified by actually running code, it takes precedence over anything that just looks correct on read.

---

## Source of truth for this project

- 01-foundation.md, 02-prd.md, 03-tdd.md are the settled scope and architecture. Don't silently redesign decisions made in those documents — if something in them turns out to be wrong once building starts, flag it explicitly and update the document, rather than quietly diverging.
- If duplicate versions of any file exist (e.g. two `models.py`), name one canonical explicitly and say so. Never leave it ambiguous which one is real.

## Never trust a claim until it's been run

- Every database model must be executed against a real Postgres database before being handed off — not just read for correctness. Run actual inserts, check constraints fire, check `NOT NULL` actually rejects empty strings (not just missing values — this was a real gap caught on AJOKE HUB).
- Every validator (PIN format, age/class input, content-type checks) must be tested with the exact bad input it's meant to reject, not just the happy path.
- When a bug fix is reported as done, verify by diffing before/after code — don't accept "fixed" as fact without checking.
- If a claim about Gemini's API behavior (rate limits, supported input types, response format) matters to a decision, verify it against current Gemini documentation rather than assuming from general knowledge — free-tier terms and limits change.

## Money/scoring-equivalent rules for this project

AJOKE HUB's rule was "recompute anything money-related server-side, never trust client-submitted totals." The equivalent here:
- **Streaks and badges are computed server-side only.** Never trust a client-submitted claim of "I did X today" — the server determines streak continuity and badge eligibility from logged `messages`/`conversations` data.
- **Progress topics are derived from actual logged conversation content**, not from any client-side claim of what a student studied.

## Data handling & privacy rules

- PINs are always stored hashed, never in plaintext, at rest or in logs.
- Never log full conversation content in application logs in a way that's more exposed than the database itself — students are minors, treat their data conservatively.
- If Gemini's free-tier terms mean prompts may be used to improve Google's products (true outside EEA/UK/Switzerland, which includes Nigeria), this must be disclosed in a user-facing notice before launch. Don't let this stay an implementation detail nobody surfaces to users/parents.
- Don't send more student context to Gemini than the companion service actually needs for the response — minimize what leaves the system per request.

## Testing discipline

- Test the failure case, not just the success case, for every new endpoint: bad PIN, missing signup fields, unsupported content type, oversized image upload, Gemini API timeout/failure.
- Schema compatibility must be checked against Postgres directly (dialect-specific behavior, not assumed from generic SQL).
- Rate-limit logic on the chat endpoint should be tested by actually exceeding the limit, not just reviewed.

## Documentation & continuity discipline

- If this project spans multiple AI tools or sessions, maintain a single `PROJECT_BRIEF.md` (not yet created — create it once active building starts) that any assistant can read cold, with zero prior context.
- Update that brief in place as work progresses — don't rewrite it from scratch each time. Include a "last verified" note and whether it was verified by running code or just reading it.
- Any bug report handed to a different tool (e.g. a Copilot-ready prompt) should include the literal current buggy code, the exact fix required, and acceptance criteria that forces verification by running, not just inspection.

## Scope discipline

- Non-goals from 02-prd.md (WhatsApp, payments, school dashboards, curriculum alignment, adaptive learning paths) are not to be built "while we're at it." If a shortcut or half-implementation of one of these shows up naturally during building, flag it rather than quietly including it.
- If a scope cut becomes necessary to hit a timeline, document the reasoning explicitly (per the AJOKE HUB shipping-complexity example) rather than dropping it silently.

## Writing & copy rules

- No em dashes, anywhere: code comments, commit messages, UI copy, documentation, Temmy's actual responses to students. Use periods, commas, or restructure the sentence instead.

---

*This is the last of the planning documents in this sequence. Next: app flow & schema validation, then active build.*
